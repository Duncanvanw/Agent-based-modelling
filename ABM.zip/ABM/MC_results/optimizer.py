import pandas as pd
import re

def parse_line(line):
    """Parse a single line of the data file."""
    if "Missing data" in line:
        return None
    match = re.search(r'Cost: (\d+), Makespan: +(\d+) \(agent \d+\), CPU time: (\d+.\d+), Goal priority: \w+, iteration: (\d+)', line)
    if match:
        return {
            'Cost': int(match.group(1)),
            'Makespan': int(match.group(2)),
            'CPU_Time': float(match.group(3)),
            'Iteration': int(match.group(4))
        }
    return None

def read_data(file_path):
    """Read and parse the data from the file."""
    data = []
    with open(file_path, 'r') as file:
        for line in file:
            parsed_data = parse_line(line)
            if parsed_data:
                data.append(parsed_data)
    return pd.DataFrame(data)

def calculate_statistics(df):
    """Calculate the requested statistics from the DataFrame."""
    avg_cost = df['Cost'].mean()
    avg_makespan = df['Makespan'].mean()
    avg_cpu_time = df['CPU_Time'].mean()
    total_cpu_time = df['CPU_Time'].sum()
    missing_calculations = len(df) - df['Iteration'].count()

    return avg_cost, avg_makespan, avg_cpu_time, total_cpu_time, missing_calculations

if __name__ == "__main__":
    solver_type = "CBS"
    num_iterations = 100
    file_paths = [
        f"MC_results\\MC_results_{solver_type}false_iterations_{num_iterations}.txt",
        f"MC_results\\MC_results_{solver_type}higher_iterations_{num_iterations}.txt",
        f"MC_results\\MC_results_{solver_type}true_iterations_{num_iterations}.txt",
        f"MC_results\\MC_results_{solver_type}lower_iterations_{num_iterations}.txt"
    ]
    all_data = pd.DataFrame()

    for path in file_paths:
        df = read_data(path)
        all_data = pd.concat([all_data, df])

    best_cost_per_iteration = all_data.sort_values('Cost').groupby('Iteration').first().reset_index()
    average_cost, average_makespan, average_cpu_time, total_cpu_time, missing_calculations = calculate_statistics(all_data)


    with open(f"MC_results\\MC_results_{solver_type}_optimized.txt", 'w') as file:
        file.write(f"The Monte Carlo Simulation for {solver_type} with {num_iterations} iterations has the following results:\n"
                        f"Average cost: {round(average_cost,2)}\n"
                        f"Average makespan: {round(average_makespan,2)}\n"
                        f"Average CPU time: {round(average_cpu_time, 2)}\n"
                        f"Total Monte Carlo CPU time: {round(total_cpu_time, 2)}\n"
                        f"Missing calculations: {missing_calculations}\n\n"
                        f"{best_cost_per_iteration.to_string()}\n"
                        )



